FIBER_COST_PER_METER = 25
SPLITTER_COST = {8: 300, 16: 500, 32: 800}
FDH_COST = 2000

def estimate_costs(df, splitter_ratio, fdh_count):
    total_fiber = df['Distance_km'].sum() * 1000
    fiber_cost = total_fiber * FIBER_COST_PER_METER
    splitter_cost = SPLITTER_COST[splitter_ratio] * fdh_count
    fdh_cost = FDH_COST * fdh_count
    total = fiber_cost + splitter_cost + fdh_cost

    return {
        'Total Fiber Length (m)': round(total_fiber, 2),
        'Fiber Cost (₹)': round(fiber_cost),
        'Splitter Cost (₹)': splitter_cost,
        'FDH Cost (₹)': fdh_cost,
        'Total Project Cost (₹)': round(total)
    }
