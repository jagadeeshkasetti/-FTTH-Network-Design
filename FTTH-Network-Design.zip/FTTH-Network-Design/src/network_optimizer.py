import pandas as pd
from geopy.distance import geodesic
from sklearn.cluster import KMeans

FIBER_LOSS_DB_PER_KM = 0.35
SPLITTER_LOSS_DB = {8: 10.5, 16: 13.5, 32: 17.0}

def load_home_data(filepath):
    return pd.read_csv(filepath)

def cluster_homes(df, n_clusters):
    coords = df[['Latitude', 'Longitude']]
    kmeans = KMeans(n_clusters=n_clusters, random_state=42).fit(coords)
    df['FDH_Cluster'] = kmeans.labels_
    fdh_locations = kmeans.cluster_centers_
    return df, fdh_locations

def calculate_loss_and_distance(df, fdh_locations, splitter_ratio):
    results = []
    for _, row in df.iterrows():
        cluster = int(row['FDH_Cluster'])
        fdh_loc = fdh_locations[cluster]
        dist_km = geodesic((row['Latitude'], row['Longitude']), tuple(fdh_loc)).km
        total_loss = dist_km * FIBER_LOSS_DB_PER_KM + SPLITTER_LOSS_DB[splitter_ratio]
        results.append({
            'HomeID': row['HomeID'],
            'FDH_ID': cluster,
            'Distance_km': round(dist_km, 3),
            'Total_Loss_dB': round(total_loss, 2)
        })
    return pd.DataFrame(results)
