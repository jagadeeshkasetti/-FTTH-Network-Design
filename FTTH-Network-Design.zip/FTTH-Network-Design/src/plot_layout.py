import matplotlib.pyplot as plt

def plot_layout(df, fdh_locations, output_path):
    plt.figure(figsize=(10, 8))
    for i, fdh in enumerate(fdh_locations):
        cluster = df[df['FDH_Cluster'] == i]
        plt.scatter(cluster['Longitude'], cluster['Latitude'], label=f'FDH {i}')
        plt.scatter(fdh[1], fdh[0], marker='x', color='black', s=100)
    plt.title("FTTH Layout")
    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.legend()
    plt.grid(True)
    plt.savefig(output_path)
    plt.close()
