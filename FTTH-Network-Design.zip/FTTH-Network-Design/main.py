from src.network_optimizer import load_home_data, cluster_homes, calculate_loss_and_distance
from src.cost_estimator import estimate_costs
from src.plot_layout import plot_layout
import pandas as pd
import os

# Ensure output folder exists
os.makedirs("output", exist_ok=True)

# Parameters
splitter_ratio = 16
num_clusters = 4

# Load home coordinates
home_df = load_home_data("data/homes_coordinates.csv")

# Cluster homes to FDHs
clustered_df, fdh_locations = cluster_homes(home_df, n_clusters=num_clusters)

# Calculate distances and signal loss
results_df = calculate_loss_and_distance(clustered_df, fdh_locations, splitter_ratio)
results_df.to_excel("output/loss_distance_report.xlsx", index=False)

# Estimate total project cost
cost_summary = estimate_costs(results_df, splitter_ratio, num_clusters)
pd.DataFrame([cost_summary]).to_excel("output/cost_report.xlsx", index=False)

# Plot layout
plot_layout(clustered_df, fdh_locations, "output/layout_map.png")

print("✅ FTTH network design complete! Results saved in /output.")
